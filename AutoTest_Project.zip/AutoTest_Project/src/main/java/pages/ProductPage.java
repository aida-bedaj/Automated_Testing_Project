package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class ProductPage {
    private WebDriver driver;

    // Locators
    private By productItems = By.cssSelector(".product-item");
    private By addToWishListButton = By.cssSelector(".action.towishlist");
    private By addToCartButton = By.cssSelector(".action.tocart");
    private By sizeOptions = By.cssSelector(".swatch-option.text");
    private By colorOptions = By.cssSelector(".swatch-option.color");
    private By successMessage = By.cssSelector(".message-success.success.message");

    // Constructor
    public ProductPage(WebDriver driver) {
        this.driver = driver;
    }

    // Methods
    public List<WebElement> getProductItems() {
        return driver.findElements(productItems);
    }

    public void selectSize(WebElement product, int index) {
        List<WebElement> sizes = product.findElements(sizeOptions);
        if (sizes.size() > index) {
            sizes.get(index).click();
        }
    }

    public void selectColor(WebElement product, int index) {
        List<WebElement> colors = product.findElements(colorOptions);
        if (colors.size() > index) {
            colors.get(index).click();
        }
    }

    public void addToWishList(WebElement product) {
        product.findElement(addToWishListButton).click();
    }

    public void addToCart(WebElement product) {
        product.findElement(addToCartButton).click();
    }

    public boolean isSuccessMessageDisplayed() {
        return driver.findElement(successMessage).isDisplayed();
    }
}
