package tests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import java.util.List;

public class WishListTest extends BaseTest {

    @Test
    public void testWishList() {
        driver.get("https://magento.softwaretestingboard.com/");

        // Sign In
        driver.findElement(By.linkText("Sign In")).click();
        driver.findElement(By.id("email")).sendKeys("aida_bedaj@universitetipolis.edu.al");
        driver.findElement(By.id("pass")).sendKeys("Selenimum1!");
        driver.findElement(By.id("send2")).click();

        // Navigate to Women's Jackets Page
        driver.findElement(By.linkText("Women")).click();
        driver.findElement(By.linkText("Tops")).click();
        driver.findElement(By.linkText("Jackets")).click();

        // Remove Price Filter if applied
        List<WebElement> clearFilters = driver.findElements(By.cssSelector(".filter-current .action.remove"));
        for (WebElement clearFilter : clearFilters) {
            clearFilter.click();
        }

        // Verify item count increases after removing filters
        List<WebElement> itemsAfterFilterRemoval = driver.findElements(By.cssSelector(".product-item"));
        Assertions.assertTrue(itemsAfterFilterRemoval.size() > 2, "Item count did not increase after removing filters.");

        // Add first two items to Wish List
        for (int i = 0; i < 2; i++) {
            WebElement item = itemsAfterFilterRemoval.get(i);
            item.findElement(By.cssSelector(".action.towishlist")).click();

            // Verify success message
            Assertions.assertTrue(driver.findElement(By.cssSelector(".message-success.success.message")).isDisplayed(),
                    "Success message not displayed after adding to Wish List.");
        }

        // Verify items in Wish List
        driver.findElement(By.cssSelector(".header .customer-welcome")).click();
        driver.findElement(By.linkText("My Wish List")).click();

        List<WebElement> wishListItems = driver.findElements(By.cssSelector(".wishlist .product-item"));
        Assertions.assertEquals(2, wishListItems.size(), "Incorrect number of items in Wish List.");
    }
}
