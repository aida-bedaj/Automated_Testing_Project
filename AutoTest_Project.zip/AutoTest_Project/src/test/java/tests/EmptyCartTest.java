package tests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class EmptyCartTest extends BaseTest {

    @Test
    public void testEmptyShoppingCart() {
        driver.get("https://magento.softwaretestingboard.com/");

        // Sign In
        driver.findElement(By.linkText("Sign In")).click();
        driver.findElement(By.id("email")).sendKeys("aida_bedaj@universitetipolis.edu.al");
        driver.findElement(By.id("pass")).sendKeys("Selenimum1!");
        driver.findElement(By.id("send2")).click();

        // Open the Shopping Cart
        driver.findElement(By.cssSelector(".showcart")).click();
        driver.findElement(By.linkText("View and Edit Cart")).click();

        // Delete all items from the cart
        List<WebElement> cartItems;
        while (!(cartItems = driver.findElements(By.cssSelector(".cart.item"))).isEmpty()) {
            WebElement deleteButton = cartItems.get(0).findElement(By.cssSelector(".action.delete"));
            deleteButton.click();
            driver.findElement(By.cssSelector(".action-primary.action-accept")) // Confirm delete
                    .click();

            // Verify cart items decrease
            int newCount = driver.findElements(By.cssSelector(".cart.item")).size();
            Assertions.assertEquals(cartItems.size() - 1, newCount, "Item count did not decrease after deletion.");
        }

        // Verify cart is empty
        WebElement emptyMessage = driver.findElement(By.cssSelector(".cart-empty p"));
        Assertions.assertTrue(emptyMessage.getText().contains("You have no items in your shopping cart."),
                "Shopping cart is not empty.");

        // Close the browser
        driver.quit();
    }
}
