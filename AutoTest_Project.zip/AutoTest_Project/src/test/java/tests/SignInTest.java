package tests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import pages.HomePage;
import pages.SignInPage;

public class SignInTest extends BaseTest {

    @Test
    public void testSignIn() {
        driver.get("https://magento.softwaretestingboard.com/");

        // Navigate to Sign In Page
        HomePage homePage = new HomePage(driver);
        homePage.clickSignIn();

        // Login with valid credentials
        SignInPage signInPage = new SignInPage(driver);
        signInPage.enterEmail("aida_bedaj@universitetipolis.edu.al"); // Use the email created in CreateAccountTest
        signInPage.enterPassword("Selenimum1!");
        signInPage.clickSignIn();

        // Verify User Profile is Displayed
        Assertions.assertTrue(signInPage.isUserProfileDisplayed(), "User profile is not displayed after login.");
    }
}
