package tests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.HomePage;
import pages.SignInPage;

import java.time.Duration;
import java.util.List;

public class FilterTest extends BaseTest {

    @Test
    public void testPageFilters() {
        driver.get("https://magento.softwaretestingboard.com/");

        // Sign In
        HomePage homePage = new HomePage(driver);
        homePage.clickSignIn();

        SignInPage signInPage = new SignInPage(driver);
        signInPage.enterEmail("aida_bedaj@universitetipolis.edu.al"); // Use the email created in CreateAccountTest
        signInPage.enterPassword("Selenimum1!");
        signInPage.clickSignIn();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        Actions actions = new Actions(driver);

        // Navigate to Women's Jackets Page using hover actions
        WebElement womenMenu = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Women")));
        actions.moveToElement(womenMenu).perform();

        WebElement topsMenu = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Tops")));
        actions.moveToElement(topsMenu).perform();

        WebElement jacketsLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Jackets")));
        jacketsLink.click();

        // Apply Color Filter
        driver.findElement(By.xpath("//div[@aria-label='Color']//div[contains(@option-label, 'Red')]"))
                .click();

        // Verify all displayed products have the selected color
        List<WebElement> colorElements = driver.findElements(By.cssSelector(".swatch-option.color"));
        for (WebElement colorElement : colorElements) {
            Assertions.assertTrue(colorElement.getAttribute("aria-label").contains("Red"),
                    "Product color is not as expected.");
        }

        // Apply Price Filter
        driver.findElement(By.xpath("//div[@aria-label='Price']//div[contains(@option-label, '$50.00 - $59.99')]"))
                .click();

        // Verify only two products are displayed
        List<WebElement> products = driver.findElements(By.cssSelector(".product-item"));
        Assertions.assertEquals(2, products.size(), "Unexpected number of products displayed.");

        // Verify prices match the defined criteria
        for (WebElement product : products) {
            String priceText = product.findElement(By.cssSelector(".price")).getText().replace("$", "");
            double price = Double.parseDouble(priceText);
            Assertions.assertTrue(price >= 50.00 && price <= 59.99, "Product price is out of range.");
        }
    }
}
