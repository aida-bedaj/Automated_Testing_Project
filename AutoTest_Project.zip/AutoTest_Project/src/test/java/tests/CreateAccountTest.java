package tests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import pages.CreateAccountPage;
import pages.HomePage;

public class CreateAccountTest extends BaseTest {

    @Test
    public void testCreateAccount() {
        driver.get("https://magento.softwaretestingboard.com/");

        // Navigate to Create Account Page
        HomePage homePage = new HomePage(driver);
        homePage.clickCreateAccount();

        // Fill in Account Details
        CreateAccountPage createAccountPage = new CreateAccountPage(driver);
        createAccountPage.enterFirstName("Aida");
        createAccountPage.enterLastName("Bedaj");
        createAccountPage.enterEmail("aida_bedaj@universitetipolis.edu.al");
        createAccountPage.enterPassword("Selenimum1!");
        createAccountPage.enterConfirmPassword("Selenimum1!");
        createAccountPage.clickCreateAccount();

        // Verify Success Message
        Assertions.assertTrue(createAccountPage.isSuccessMessageDisplayed(), "Account creation was not successful.");
    }
}
