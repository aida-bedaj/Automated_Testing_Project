package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.junit.jupiter.api.BeforeEach;

public class BaseTest {
    protected WebDriver driver;

    @BeforeEach
    public void setUp() {
        // Set the path to ChromeDriver if needed
        System.setProperty("webdriver.chrome.driver", "C:/Users/Admin/.cache/selenium/chromedriver/win64/133.0.6943.98/chromedriver.exe");

        // Simplify Chrome options
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        // Remove or comment out the user-data-dir and profile-directory options
        // options.addArguments("user-data-dir=C:/Users/Admin...");
        // options.addArguments("profile-directory=Profile 1");

        driver = new ChromeDriver(options);
    }
}