package tests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class ShoppingCartTest extends BaseTest {

    @Test
    public void testShoppingCart() {
        driver.get("https://magento.softwaretestingboard.com/");

        // Sign In
        driver.findElement(By.linkText("Sign In")).click();
        driver.findElement(By.id("email")).sendKeys("john.doe@example.com");
        driver.findElement(By.id("pass")).sendKeys("Password123");
        driver.findElement(By.id("send2")).click();

        // Navigate to Women's Jackets Page
        driver.findElement(By.linkText("Women")).click();
        driver.findElement(By.linkText("Tops")).click();
        driver.findElement(By.linkText("Jackets")).click();

        // Add all displayed items to the Shopping Cart
        List<WebElement> products = driver.findElements(By.cssSelector(".product-item"));
        for (WebElement product : products) {
            product.findElement(By.cssSelector(".swatch-option.text")) // Select size
                    .click();
            product.findElement(By.cssSelector(".action.tocart"))      // Add to cart
                    .click();

            // Verify success message
            Assertions.assertTrue(driver.findElement(By.cssSelector(".message-success.success.message")).isDisplayed(),
                    "Success message not displayed after adding to cart.");
        }

        // Open the Shopping Cart
        driver.findElement(By.cssSelector(".message-success .action.viewcart")).click();

        // Verify navigation to Shopping Cart Page
        Assertions.assertTrue(driver.getTitle().contains("Shopping Cart"),
                "Did not navigate to Shopping Cart page.");

        // Verify total price
        List<WebElement> prices = driver.findElements(By.cssSelector(".cart.item .price"));
        double totalPrice = 0;
        for (WebElement priceElement : prices) {
            String priceText = priceElement.getText().replace("$", "");
            totalPrice += Double.parseDouble(priceText);
        }

        String orderTotalText = driver.findElement(By.cssSelector(".totals .grand .price")).getText().replace("$", "");
        double orderTotal = Double.parseDouble(orderTotalText);

        Assertions.assertEquals(totalPrice, orderTotal, "Order total does not match the sum of item prices.");
    }
}
