package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class ShoppingCartPage {
    private final WebDriver driver;

    // Locators
    private final By cartItems = By.cssSelector(".cart.item");
    private final By deleteButton = By.cssSelector(".action.delete");
    private final By confirmDeleteButton = By.cssSelector(".action-primary.action-accept");
    private final By emptyCartMessage = By.cssSelector(".cart-empty p");
    private final By itemPrice = By.cssSelector(".price");
    private final By orderTotalPrice = By.cssSelector(".totals .grand .price");

    // Constructor
    public ShoppingCartPage(WebDriver driver) {
        this.driver = driver;
    }

    // Methods
    public List<WebElement> getCartItems() {
        return driver.findElements(cartItems);
    }

    public void deleteItem(WebElement item) {
        item.findElement(deleteButton).click();
        driver.findElement(confirmDeleteButton).click();
    }

    public boolean isCartEmpty() {
        return driver.findElement(emptyCartMessage).isDisplayed();
    }

    public double getItemPrice(WebElement item) {
        String priceText = item.findElement(itemPrice).getText().replace("$", "");
        return Double.parseDouble(priceText);
    }

    public double getOrderTotalPrice() {
        String totalPriceText = driver.findElement(orderTotalPrice).getText().replace("$", "");
        return Double.parseDouble(totalPriceText);
    }
}
