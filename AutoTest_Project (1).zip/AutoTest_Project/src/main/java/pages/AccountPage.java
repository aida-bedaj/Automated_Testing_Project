package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AccountPage {
    private final WebDriver driver;

    // Locators
    private final By userProfileDropdown = By.cssSelector(".customer-welcome");
    private final By signOutLink = By.linkText("Sign Out");
    private final By wishListLink = By.linkText("My Wish List");

    // Constructor
    public AccountPage(WebDriver driver) {
        this.driver = driver;
    }

    // Methods
    public void clickUserProfile() {
        driver.findElement(userProfileDropdown).click();
    }

    public void clickSignOut() {
        clickUserProfile();
        driver.findElement(signOutLink).click();
    }

    public void goToWishList() {
        clickUserProfile();
        driver.findElement(wishListLink).click();
    }

    public boolean isSignedOut() {
        return driver.findElements(signOutLink).isEmpty();
    }
}
