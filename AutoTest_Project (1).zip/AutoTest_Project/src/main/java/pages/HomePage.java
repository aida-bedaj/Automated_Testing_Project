package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
    private final WebDriver driver;

    // Locators
    private final By createAccountLink = By.linkText("Create an Account");
    private final By signInLink = By.linkText("Sign In");

    // Constructor
    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    // Methods to interact with elements
    public void clickCreateAccount() {
        driver.findElement(createAccountLink).click();
    }

    public void clickSignIn() {
        driver.findElement(signInLink).click();
    }

    public String getPageTitle() {
        return driver.getTitle();
    }
}
