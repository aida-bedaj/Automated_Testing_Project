plugins {
    id("java")
}

group = "com.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    implementation(platform("org.junit:junit-bom:5.10.0"))  // Import the JUnit BOM (Bill of Materials) to manage JUnit versions consistently
    implementation("org.junit.jupiter:junit-jupiter:5.10.0")  // Add JUnit Jupiter API for writing unit tests (JUnit 5)
    implementation("org.seleniumhq.selenium:selenium-java:4.16.1") // Add Selenium Java library for browser automation
    implementation ("org.seleniumhq.selenium:selenium-devtools-v114:4.12.1") // Add Selenium DevTools for interacting with Chrome DevTools Protocol (specific version v114)
    implementation("io.github.bonigarcia:webdrivermanager:5.5.3") // Add WebDriverManager to automatically manage browser drivers
    implementation("com.aventstack:extentreports:5.0.9") // Add ExtentReports library for generating detailed test reports
    implementation("commons-io:commons-io:2.15.0")// Add Apache Commons IO library for file operations (e.g., copying, reading)
    implementation("org.slf4j:slf4j-simple:2.0.9")  // Add SLF4J Simple library for simple logging capabilities
    implementation("com.fasterxml.jackson.core:jackson-core:2.17.0") // Add Jackson Core library for JSON processing (core part of Jackson library)
    implementation("com.fasterxml.jackson.core:jackson-databind:2.17.0") // Add Jackson Databind library for converting Java objects to JSON and vice versa
    implementation("org.apache.commons:commons-compress:1.27.1") // Add Apache Commons Compress library for handling compressed files (ZIP, TAR, etc.)
    implementation("org.bouncycastle:bcprov-jdk18on:1.80") // Add Bouncy Castle library for cryptographic operations and security-related functionality

}
tasks.test {
    useJUnitPlatform()
}